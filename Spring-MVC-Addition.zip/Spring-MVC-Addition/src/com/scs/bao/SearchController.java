package com.scs.bao;

import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.hibernate.Criteria;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;
import org.hibernate.criterion.Criterion;
import org.hibernate.criterion.Restrictions;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import com.scs.dao.Emp;

@Controller
public class SearchController {
	
@RequestMapping("search")	
public String Search()
{
  return "Search";	
}
@RequestMapping("searchdata")	
public ModelAndView Searchdata(HttpServletRequest request)
{
	Configuration cfg = new Configuration();
	cfg.configure("hibernate.cfg.xml");
	SessionFactory sf = cfg.buildSessionFactory();
	Session sess = sf.openSession();
	//Query q = sess.createQuery("from Emp e where e.empname=?");
	//q.setString(0,request.getParameter("q"));
	Criteria cq = sess.createCriteria(Emp.class);
	Criterion rt = Restrictions.like("empname",request.getParameter("q")+"%");
	cq.add(rt);
	List lst = cq.list();
	ModelAndView obj= new ModelAndView("searchdata");
	obj.addObject("res", lst);
	return obj;	
}
}
