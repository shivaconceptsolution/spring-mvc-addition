package com.scs.bao;

import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.scs.dao.Admin;
import com.scs.dao.Emp;
@Controller
public class LoginController {
	@RequestMapping("login")
    public ModelAndView login(){
    	return new ModelAndView("adminlogin","command",new Admin());
    }
	@RequestMapping(value="loginlogic",method=RequestMethod.POST)
    public ModelAndView loginlogic(@ModelAttribute("Spring-MVC-Addition")Admin s){
		Configuration cfg = new Configuration();
		cfg.configure("hibernate.cfg.xml");
		SessionFactory sf = cfg.buildSessionFactory();
		Session sess = sf.openSession();
		Query q = sess.createQuery("from Admin a where a.username=? and a.password=?");
		q.setString(0,s.getUsername());
		q.setString(1,s.getPassword());
		List lst = q.list();
		String s1 = "";
		if(lst.size()>0)
		{
			return new ModelAndView("redirect:dashboard.html");
		}
		else
		{
			s1 = "Login not Successfully";
		}
    	ModelAndView obj = new ModelAndView("adminlogin","command",new Admin());
    	obj.addObject("res",s1);
        return obj;
    }
}
