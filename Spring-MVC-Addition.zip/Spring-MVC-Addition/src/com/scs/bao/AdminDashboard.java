package com.scs.bao;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import com.scs.dao.Admin;
@Controller
public class AdminDashboard {
	@RequestMapping("dashboard")
    public ModelAndView dashboard(){
    	return new ModelAndView("dashboard");
    }
}
