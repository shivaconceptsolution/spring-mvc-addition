package com.scs.bao;

import java.io.IOException;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import com.oreilly.servlet.MultipartRequest;
import com.scs.dao.Admin;
@Controller
public class AdminDashboard {
	@RequestMapping("dashboard")
    public ModelAndView dashboard(HttpServletRequest request){
		HttpSession session = request.getSession();
		if(session.getAttribute("uid")==null)
		{
			return new ModelAndView("redirect:login.html");
		}
		return new ModelAndView("dashboard");
    }
	@RequestMapping("logout")
    public ModelAndView logout(HttpServletRequest request){
		HttpSession session = request.getSession();
		session.removeAttribute("uid");
    	return new ModelAndView("redirect:login.html");
    }
	
	@RequestMapping("postjob")
	 public ModelAndView postJob(){
	return new ModelAndView("postjob");	
	}
	
	@RequestMapping("uploadjob")
	 public ModelAndView uploadJob(HttpServletRequest request){
    String data="";
		
		MultipartRequest m;
		try {
			m = new MultipartRequest(request,"C:\\Users\\Hp\\workspace\\Spring-MVC-Addition\\WebContent\\upload",3*50*1024*1024);
			data = m.getFilesystemName("file");
		} catch (IOException e) {
			data = e.getMessage();
		}
		
		
	
	return new ModelAndView("postjob","msg",data);	
	}
	
	
}
